const {
  Client,
  GatewayIntentBits,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  InteractionType,
  PermissionsBitField,
  REST,
  Routes,
  SlashCommandBuilder
} = require("discord.js");

const config = require("./config.json");

/* =========================
   CLIENT
========================= */
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildBans,
    GatewayIntentBits.GuildVoiceStates
  ]
});

/* =========================
   READY + SLASH REGISTER
========================= */
client.once("ready", async () => {
  console.log(`✅ Eingeloggt als ${client.user.tag}`);

  const commands = [
    new SlashCommandBuilder()
      .setName("ticketpanel")
      .setDescription("Sendet das Ticket Panel"),
    new SlashCommandBuilder()
      .setName("selfroles")
      .setDescription("Sendet das Selfrole Panel"),
    new SlashCommandBuilder()
      .setName("disclaimer")
      .setDescription("Sendet ein interaktives Disclaimer-Embed")
      .addStringOption(option =>
        option.setName("hex")
          .setDescription("Hex-Code der Embed-Farbe, z.B. ff0000")
          .setRequired(true)
      )
      .addStringOption(option =>
        option.setName("überschrift")
          .setDescription("Die Überschrift des Embeds")
          .setRequired(true)
      )
      .addStringOption(option =>
        option.setName("text")
          .setDescription("Der Text, der im Embed erscheinen soll")
          .setRequired(true)
      )
  ].map(c => c.toJSON());

  const rest = new REST({ version: "10" }).setToken(config.token);
  try {
    await rest.put(
      Routes.applicationGuildCommands(config.clientId, config.guildId),
      { body: commands }
    );
    console.log("✅ Slash Commands registriert");
  } catch (err) {
    console.error("❌ Fehler beim Registrieren der Slash Commands:", err);
  }
});

/* =========================
   WELCOME MESSAGE
========================= */
client.on("guildMemberAdd", async member => {
  try {
    const channel = member.guild.channels.cache.get(config.welcomeChannelId);
    if (!channel) return;
    const embed = new EmbedBuilder()
      .setColor("Green")
      .setTitle(`🎉 Willkommen auf Sinclair Settings!`)
      .setDescription(`Hey <@${member.id}>, willkommen auf **Sinclair Settings**!\nDu bist Mitglied Nr. **${member.guild.memberCount}**`)
      .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
      .setTimestamp();
    channel.send({ embeds: [embed] });
  } catch (err) {
    console.error("❌ Fehler bei Willkommensnachricht:", err);
  }
});

/* =========================
   LOG HELPER
========================= */
function logToChannel(type, content, guild) {
  const channelId = config.logChannels?.[type];
  if (!channelId) return;
  const channel = guild.channels.cache.get(channelId);
  if (!channel) return;
  channel.send({ content });
}

/* =========================
   INTERACTIONS
========================= */
client.on("interactionCreate", async interaction => {
  try {
    /* ===== SLASH COMMANDS ===== */
    if (interaction.isChatInputCommand()) {
      const ownerRole = config.ownerRoleId;
      const member = await interaction.guild.members.fetch(interaction.user.id);
      const isOwner = member.roles.cache.has(ownerRole);

      const ownerOnlyCommands = ["ticketpanel", "selfroles", "disclaimer"];
      if (ownerOnlyCommands.includes(interaction.commandName) && !isOwner) {
        return interaction.reply({
          content: "❌ Du hast keine Berechtigung, diesen Befehl auszuführen. Nur Benutzer mit der Owner-Rolle dürfen das.",
          ephemeral: true
        });
      }

      if (interaction.commandName === "ticketpanel") {
        await sendTicketPanel(interaction.channel);
        return interaction.reply({ content: "✅ Ticket Panel gesendet", ephemeral: true });
      }

      if (interaction.commandName === "selfroles") {
        await sendSelfRolePanel(interaction.channel);
        return interaction.reply({ content: "✅ Selfroles Panel gesendet", ephemeral: true });
      }

      if (interaction.commandName === "disclaimer") {
        await interaction.deferReply({ ephemeral: false });
        let color = interaction.options.getString("hex").trim();
        const title = interaction.options.getString("überschrift");
        const text = interaction.options.getString("text");
        if (!color.startsWith("#")) color = "#" + color;
        if (!/^#([0-9A-Fa-f]{6})$/.test(color)) {
          return interaction.editReply("❌ Bitte gib eine gültige HEX-Farbe ein (z.B. #ff0000)");
        }
        const embed = new EmbedBuilder()
          .setColor(color)
          .setTitle(title)
          .setDescription(text)
          .setTimestamp();
        return interaction.editReply({ embeds: [embed] });
      }
    }

    /* ===== BUTTONS ===== */
    if (interaction.isButton()) {
      // Selfroles
      if (["twitch", "tiktok", "giveaway"].includes(interaction.customId)) {
        const roleId = config.roles[interaction.customId];
        const role = interaction.guild.roles.cache.get(roleId);
        if (!role) return interaction.reply({ content: "❌ Rolle nicht gefunden", ephemeral: true });
        if (interaction.member.roles.cache.has(roleId)) {
          await interaction.member.roles.remove(role);
          return interaction.reply({ content: `❌ **${role.name}** entfernt`, ephemeral: true });
        } else {
          await interaction.member.roles.add(role);
          return interaction.reply({ content: `✅ **${role.name}** hinzugefügt`, ephemeral: true });
        }
      }

      // Ticket schließen
      if (interaction.customId === "ticket_close") {
        await interaction.deferReply({ ephemeral: true });
        const ownerId = interaction.channel.topic?.split(":")[1];
        const transcript = await createTranscript(interaction.channel);
        if (ownerId) {
          const user = await interaction.guild.members.fetch(ownerId).catch(() => null);
          if (user) {
            await user.send({
              content: "📄 Dein Ticket Transcript:",
              files: [{ attachment: Buffer.from(transcript), name: `${interaction.channel.name}.txt` }]
            }).catch(() => {});
          }
        }
        if (config.logChannels?.["ticket-logs"]) {
          logToChannel("ticket-logs", `📄 Ticket von ${interaction.user.tag} geschlossen: ${interaction.channel.name}`, interaction.guild);
        }
        await interaction.editReply("✅ Ticket wird geschlossen...");
        setTimeout(() => interaction.channel.delete().catch(() => {}), 3000);
        return;
      }

      // Ticket Modal für Buttons
      const ticketButtons = ["pve", "citizen", "bundle", "soundpack", "skins", "support", "minimaps"];
      if (ticketButtons.includes(interaction.customId)) {
        const modal = new ModalBuilder()
          .setCustomId(`modal_${interaction.customId}`)
          .setTitle("Ticket erstellen");
        modal.addComponents(
          new ActionRowBuilder().addComponents(
            new TextInputBuilder()
              .setCustomId("product")
              .setLabel("Bitte sag uns, was du möchtest")
              .setStyle(TextInputStyle.Short)
              .setRequired(true)
          ),
          new ActionRowBuilder().addComponents(
            new TextInputBuilder()
              .setCustomId("payment")
              .setLabel("Wie möchtest du bezahlen?")
              .setStyle(TextInputStyle.Short)
              .setRequired(true)
          )
        );
        await interaction.showModal(modal);
      }
    }

    /* ===== MODAL SUBMIT ===== */
    if (interaction.type === InteractionType.ModalSubmit) {
      const type = interaction.customId.replace("modal_", "");
      const product = interaction.fields.getTextInputValue("product");
      const payment = interaction.fields.getTextInputValue("payment");
      return createTicket(interaction, type, { product, payment });
    }

  } catch (err) {
    console.error("❌ Interaction Fehler:", err);
  }
});

/* =========================
   PANELS
========================= */
async function sendTicketPanel(channel) {
  const embed = new EmbedBuilder()
    .setColor("Green")
    .setTitle("🎫 Ticket erstellen")
    .setDescription("Wähle aus, welches Ticket du öffnen möchtest")
    .setImage("https://i.imgur.com/febyaTS.png");

  const row1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId("pve").setLabel("PVE").setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId("citizen").setLabel("Citizen").setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId("bundle").setLabel("Bundle").setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId("soundpack").setLabel("Soundpack").setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId("skins").setLabel("Waffenskins").setStyle(ButtonStyle.Primary)
  );

  const row2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId("support").setLabel("Support").setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId("minimaps").setLabel("Mini Maps").setStyle(ButtonStyle.Success)
  );

  await channel.send({ embeds: [embed], components: [row1, row2] });
}

async function sendSelfRolePanel(channel) {
  const embed = new EmbedBuilder()
    .setColor("Blue")
    .setTitle("🔔 Ping Rollen")
    .setDescription("Klicke auf die Buttons, um Rollen zu erhalten oder zu entfernen");

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId("twitch").setLabel("Twitch Ping").setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId("tiktok").setLabel("TikTok Ping").setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId("giveaway").setLabel("Giveaway Ping").setStyle(ButtonStyle.Success)
  );

  await channel.send({ embeds: [embed], components: [row] });
}

/* =========================
   CREATE TICKET
========================= */
async function createTicket(interaction, type, data) {
  const categoryId = config.ticketCategories[type];
  if (!categoryId) return;

  const channel = await interaction.guild.channels.create({
    name: `ticket-${interaction.user.username}-${type}`,
    parent: categoryId,
    topic: `owner:${interaction.user.id}`,
    permissionOverwrites: [
      { id: interaction.guild.id, deny: [PermissionsBitField.Flags.ViewChannel] },
      { id: interaction.user.id, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages] }
    ]
  });

  const embed = new EmbedBuilder()
    .setColor("Blue")
    .setTitle("🎟 Ticket eröffnet")
    .setDescription(
      data ? `**Produkt:** ${data.product}\n**Bezahlung:** ${data.payment}` : "Support Ticket"
    );

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId("ticket_close").setLabel("Ticket schließen").setStyle(ButtonStyle.Danger)
  );

  await channel.send({ embeds: [embed], components: [row] });
  interaction.reply({ content: `✅ Ticket erstellt: ${channel}`, ephemeral: true });

  // =========================
  // TICKET-LOG
  // =========================
  if (config.logChannels?.["ticket-logs"]) {
    const logMessage = `🎫 Neues Ticket erstellt von **${interaction.user.tag}** (${interaction.user.id})
**Ticket-Kanal:** ${channel}
**Ticket-Typ:** ${type}
**Produkt:** ${data.product}
**Bezahlung:** ${data.payment}`;
    logToChannel("ticket-logs", logMessage, interaction.guild);
  }
}

/* =========================
   TRANSCRIPT
========================= */
async function createTranscript(channel) {
  let messages = [];
  let lastId;
  while (true) {
    const fetched = await channel.messages.fetch({ limit: 100, before: lastId });
    if (fetched.size === 0) break;
    fetched.forEach(msg => {
      messages.push(`[${msg.createdAt.toLocaleString()}] ${msg.author.tag}: ${msg.content || "[Embed/Anhang]"}`);
    });
    lastId = fetched.last().id;
  }
  return messages.reverse().join("\n");
}

/* =========================
   LOGIN
========================= */
client.login(config.token);