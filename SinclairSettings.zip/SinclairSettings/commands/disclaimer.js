const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("disclaimer")
    .setDescription("Sendet ein Disclaimer Embed")
    .addStringOption(opt =>
      opt.setName("text")
        .setDescription("Disclaimer Text")
        .setRequired(true)
    ),

  async execute(interaction) {
    try {
      const text = interaction.options.getString("text");

      const embed = new EmbedBuilder()
        .setColor("Red")
        .setTitle("⚠️ Disclaimer")
        .setDescription(text)
        .setTimestamp();

      await interaction.channel.send({ embeds: [embed] });
      await interaction.reply({ content: "✅ Disclaimer gesendet", ephemeral: true });

    } catch (err) {
      console.error("[ERROR][/disclaimer]", err);
      interaction.reply({ content: "❌ Fehler", ephemeral: true });
    }
  }
};
