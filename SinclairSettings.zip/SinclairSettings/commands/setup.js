const { SlashCommandBuilder } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("setup")
    .setDescription("Sendet Setup Embeds (Ping + Produkt)"),

  async execute(interaction) {
    try {
      await interaction.deferReply({ ephemeral: true });

      // Ping Buttons
      await interaction.client.sendPingEmbed(interaction.channel);

      // Produkt Auswahl
      await interaction.client.sendProductEmbed(interaction.channel);

      await interaction.editReply("✅ Setup abgeschlossen");

    } catch (err) {
      console.error("[ERROR][/setup]", err);
      interaction.editReply("❌ Fehler beim Setup");
    }
  }
};
