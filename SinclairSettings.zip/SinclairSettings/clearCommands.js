const { REST, Routes } = require("discord.js");
const config = require("./config.json");

const rest = new REST({ version: "10" }).setToken(config.token);

(async () => {
  try {
    console.log("🗑 Lösche alle globalen Slash-Commands...");
    await rest.put(Routes.applicationCommands(config.clientId), { body: [] });
    console.log("✅ Alle globalen Commands gelöscht!");
  } catch (err) {
    console.error(err);
  }
})();
